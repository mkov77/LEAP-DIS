﻿namespace OpenDis.Enumerations.Cet2010
{
    public interface IExtraOrExtraRange : IGenericEntryDescription
    {
        ulong UId { get; set; }
    }
}
