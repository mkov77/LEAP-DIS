# Open DIS for C#

C-Sharp implementation of the Distributed Interactive Simulation (DIS) standard.

Many of the classes were initially generated with [XMLPG](http://github.com/open-dis/xmlpg).
